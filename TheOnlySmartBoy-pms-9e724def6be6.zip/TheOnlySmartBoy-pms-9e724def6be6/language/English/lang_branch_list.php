<?php
//Website Menu Language Conversion
//English Package
//copyright: otema.com

$_data['text_1'] 		= "Add Branch";
$_data['text_1_1'] 		= "Update Branch";
$_data['text_2'] 		= "Branch";
$_data['text_3'] 		= "Branch Entry Form";
$_data['text_4'] 		= "Name ";
$_data['text_5'] 		= "Email";
$_data['text_6'] 		= "Contact No";
$_data['text_7'] 		= "Address";
$_data['text_8'] 		= "Status";
$_data['text_9'] 		= "Enable";
$_data['text_10'] 		= "Disable";
$_data['text_11'] 		= "Added Branch Information Successfully";
$_data['text_12'] 		= "Updated Branch Information Successfully";
$_data['text_13'] 		= "Deleted Branch Information Successfully";
$_data['text_14']		= "Branch List";
$_data['text_15'] 		= "Branch Name";
$_data['text_16']  		= "Branch Details";
$_data['text_17'] 		= "Dashboard";

?>