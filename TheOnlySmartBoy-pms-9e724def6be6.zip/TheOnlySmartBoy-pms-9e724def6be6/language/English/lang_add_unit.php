<?php
//Website Menu Language Conversion
//English Package
//copyright: otemainc.com

$_data['add_new_unit'] 	= "Add New Unit";
$_data['add_new_unit_entry_form'] = "Unit Entry Form";
$_data['add_new_form_field_text_1'] = "Floor No";
$_data['add_new_form_field_text_2'] = "Unit No";
$_data['add_new_form_field_text_3'] = "Unit Size";
$_data['add_new_unit_information_breadcam'] = "Unit Information";
$_data['add_new_unit_breadcam'] = "Add Unit";
$_data['select_floor'] 	= "Select Floor";
$_data['add_unit_successfully'] = "Add Unit Successfully";
$_data['update_unit_successfully'] = "Update Unit Successfully";
$_data['rented'] = "Rented";
$_data['vacant'] = "Vacant";
$_data['status'] = "Status";

?>