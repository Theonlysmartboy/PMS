<?php
//Website Menu Language Conversion
//English Package
//copyright: otema.com

$_data['text_1'] 		= "Fund Status";
$_data['text_2'] 		= "Image";
$_data['text_3'] 		= "Date";
$_data['text_4'] 		= "Owner Name";
$_data['text_5'] 		= "Month";
$_data['text_6'] 		= "Year";
$_data['text_7'] 		= "Amount";
$_data['text_8'] 		= "Purpose";
$_data['text_9'] 		= "Maintaining Cost Status";
$_data['text_10'] 		= "Cost Title";
$_data['text_11'] 		= "Details";
$_data['text_12'] 		= "Remain Balance";
$_data['text_13'] 		= "Print Information";


?>