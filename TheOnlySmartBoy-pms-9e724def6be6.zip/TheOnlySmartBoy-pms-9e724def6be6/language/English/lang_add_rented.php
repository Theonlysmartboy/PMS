<?php

//Website Menu Language Conversion
//English Package
//copyright: otema.com

$_data['add_new_renter'] = "Add New Tennant";
$_data['update_rent'] = "Update Rent";
$_data['add_new_renter_entry_form'] = "Tennant Entry Form";
$_data['add_new_form_field_text_1'] = "Tennant Name";
$_data['add_new_form_field_text_2'] = "Email ";
$_data['add_new_form_field_text_3'] = "Password";
$_data['add_new_form_field_text_4'] = "Contact person(Name, telephone/email)";
$_data['add_new_form_field_text_5'] = "Address";
$_data['add_new_form_field_text_6'] = "NID(National ID/ Registration Number)";
$_data['add_new_form_field_text_7'] = "Floor No";
$_data['add_new_form_field_text_8'] = "Unit No";
$_data['add_new_form_field_text_9'] = "Deposit Amount";
$_data['add_new_form_field_text_10'] = "Monthly Rent Amount";
$_data['add_new_form_field_text_11'] = "Issue Date";
$_data['add_new_form_field_text_12'] = "Rent Month";
$_data['add_new_form_field_text_13'] = "Rent Year";
$_data['add_new_form_field_text_14'] = "Status";
$_data['add_new_form_field_text_15'] = "Preview";
$_data['add_new_form_field_text_16'] = "Active";
$_data['add_new_form_field_text_17'] = "Expired";
$_data['add_new_form_field_text_18'] = "Next escalation Date";
$_data['add_new_form_field_text_19'] = "Lease Expiry Date";
$_data['select_floor'] = "Select Floor";
$_data['select_unit'] = "Select Unit";
$_data['select_month'] = "Select Month";
$_data['select_year'] = "Select Year";
$_data['add_new_renter_information_breadcam'] = "Tennant Information";
$_data['add_new_renter_breadcam'] = "Add Tennant";
$_data['added_renter_successfully'] = "Added Tennant Information Successfully";
$_data['update_renter_successfully'] = "Updated Tennant Information Successfully";
$_data['delete_renter_information'] = "Deleted Tennant Information Successfully.";
?>