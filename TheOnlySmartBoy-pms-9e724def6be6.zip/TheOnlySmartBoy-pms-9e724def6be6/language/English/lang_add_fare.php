<?php
//Website Menu Language Conversion
//English Package
//copyright: otemainc.com
$_data['add_new_rent'] = "Add New Rent";
$_data['update_rent'] = "Update Rent";
$_data['add_new_rent_information_breadcam'] = "Rent Collection";
$_data['add_new_rent_breadcam'] = "Add Rent";
$_data['add_new_rent_entry_form'] = "Rent Entry Form";
$_data['add_new_form_field_text_1'] = "Floor No";
$_data['add_new_form_field_text_2'] = "Select Floor";
$_data['add_new_form_field_text_3'] = "Unit No";
$_data['add_new_form_field_text_4'] = "Select Floor First";
$_data['add_new_form_field_text_5'] = "Tennancy Month";
$_data['add_new_form_field_text_6'] = "Tennant Name";
$_data['add_new_form_field_text_7'] = "Rent";
$_data['add_new_form_field_text_8'] = "Water Bill";
$_data['add_new_form_field_text_9'] = "Electric Bill";
$_data['add_new_form_field_text_10'] = "Gas Bill";
$_data['add_new_form_field_text_11'] = "Security Bill";
$_data['add_new_form_field_text_12'] = "Utility Bill";
$_data['add_new_form_field_text_13'] = "Other Bill";
$_data['add_new_form_field_text_14'] = "Total Rent ";
$_data['add_new_form_field_text_15'] = "Issue Date";
$_data['added_rent_successfully'] = "Added Rent Information Successfully";
$_data['update_rent_successfully'] = "Updated Rent Information Successfully";
$_data['delete_rent_information'] = "Deleted Rent Information Successfully.";
?>