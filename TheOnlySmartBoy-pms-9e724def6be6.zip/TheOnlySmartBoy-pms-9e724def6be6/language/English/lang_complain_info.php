<?php
//Website Menu Language Conversion
//English Package
//copyright: otema.com

$_data['text_1'] 		= "Date";
$_data['text_2'] 		= "Month";
$_data['text_3'] 		= "Year";
$_data['text_4'] 		= "Tittle";
$_data['text_5'] 		= "Description";
$_data['text_6'] 		= "Complains Report ";


?>