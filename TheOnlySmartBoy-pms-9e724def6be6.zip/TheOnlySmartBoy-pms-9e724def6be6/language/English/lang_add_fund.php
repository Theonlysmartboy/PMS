<?php
//Website Menu Language Conversion
//English Package
//copyright: otema.com

$_data['add_new_fund'] 						= "Add New Fund";
$_data['fund'] 								= "Fund";
$_data['update_fund'] 						= "Update Fund";
$_data['add_new_fund_breadcam'] 			= "Add Fund";
$_data['add_new_fund_entry_form'] 			= "Fund Entry Form";
$_data['add_new_form_field_text_1'] 		= "Owner Name";
$_data['add_new_form_field_text_2'] 		= "Select Owner";
$_data['add_new_form_field_text_3'] 		= "Select Month";
$_data['add_new_form_field_text_4'] 		= "Contact";
$_data['add_new_form_field_text_5'] 		= "Select Year";
$_data['add_new_form_field_text_6'] 		= "Date";
$_data['add_new_form_field_text_7'] 		= "Total Amount";
$_data['add_new_form_field_text_8'] 		= "Purpose";
$_data['added_fund_successfully'] 			= "Added Fund Information Successfully";
$_data['update_fund_successfully'] 			= "Updated Fund Information Successfully";
$_data['delete_fund_information'] 			= "Deleted Fund Information Successfully.";

?>