<?php
//Website Menu Language Conversion
//English Package
//copyright: otema.com

$_data['text_1'] 		= "Owner Utility Details";
$_data['text_2'] 		= "Owner Name";
$_data['text_3'] 		= "Floor No";
$_data['text_4'] 		= "Unit No";
$_data['text_5'] 		= "Month Name";
$_data['text_6'] 		= "Rent";
$_data['text_7'] 		= "Total Bill";
$_data['text_8'] 		= "Issue Date";
$_data['text_9'] 		= "Water Bill";
$_data['text_10'] 		= "Electric Bill";
$_data['text_11'] 		= "Gas Bill";
$_data['text_12'] 		= "Security Bill";
$_data['text_13'] 		= "Utility Bill";
$_data['text_14'] 		= "Other Bill";
$_data['text_15'] 		= "Total Rent";

?>