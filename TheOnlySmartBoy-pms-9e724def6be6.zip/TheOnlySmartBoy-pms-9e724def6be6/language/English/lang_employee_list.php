<?php
//Website Menu Language Conversion
//English Package
//copyright: otema.com

$_data['employee_list'] 							= "Employee List ";
$_data['employee_details'] 							= "Employee Details";
$_data['add_new_employee_information_breadcam'] 	= "Employee Information";
$_data['add_new_employee_breadcam'] 				= "Add Employee";
$_data['imgage'] 									= "image";
$_data['add_new_form_field_text_1'] 				= "Name";
$_data['add_new_form_field_text_2'] 				= "Email ";
$_data['add_new_form_field_text_3'] 				= "Password";
$_data['add_new_form_field_text_4'] 				= "Contact";
$_data['add_new_form_field_text_5'] 				= "Present Address";
$_data['add_new_form_field_text_6'] 				= "Permanent Address";
$_data['add_new_form_field_text_7'] 				= "NID(National ID)";
$_data['add_new_form_field_text_8'] 				= "Designation";
$_data['add_new_form_field_text_9'] 				= "Joining Date";
$_data['add_new_form_field_text_10'] 				= "Ending Date";
$_data['add_new_form_field_text_11'] 				= "Status";
$_data['add_new_form_field_text_12'] 				= "Active";
$_data['add_new_form_field_text_13'] 				= "Inactive";
$_data['add_new_form_field_text_14'] 				= "Priview";
$_data['add_new_form_field_text_15'] 				= "Select";
$_data['added_employee_successfully'] 				= "Added Employee Information Successfully";
$_data['update_employee_successfully'] 				= "Updated Employee Information Successfully";
$_data['delete_employee_information'] 				= "Deleted Employee Information Successfully.";

?>